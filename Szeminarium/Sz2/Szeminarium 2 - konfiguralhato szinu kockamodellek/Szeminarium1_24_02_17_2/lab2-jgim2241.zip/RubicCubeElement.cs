﻿namespace Szeminarium1_24_02_17_2
{
    internal class RubicCubeElement
    {
        // glcube
        // original position on start

        public GlCube glCube;
        
        public float x;
        
        public float y;

        public float z;

        public RubicCubeElement(GlCube glCube, float x, float y, float z)
        {
            this.glCube = glCube;
            this.x = x;
            this.y = y;
            this.z = z;
        }   
    }
}
