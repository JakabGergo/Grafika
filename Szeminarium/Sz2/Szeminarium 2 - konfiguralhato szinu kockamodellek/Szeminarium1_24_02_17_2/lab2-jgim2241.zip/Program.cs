﻿using Silk.NET.Input;
using Silk.NET.Maths;
using Silk.NET.OpenGL;
using Silk.NET.Windowing;

namespace Szeminarium1_24_02_17_2
{
    internal static class Program
    {
        private static CameraDescriptor cameraDescriptor = new();

        private static CubeArrangementModel cubeArrangementModel = new();

        private static List<(int,float)> lepes = new();
        const float tolerance = 0.000001f;

        private static bool forgat = false;
        private static float segedSzog = 0;
        private static Random random = new Random();


        private static IWindow window;

        private static GL Gl;

        private static uint program;

        private static GlCube glCubeCentered;

        private static GlCube glCubeRotating;

        private static List<RubicCubeElement> rcElements;

        private const string ModelMatrixVariableName = "uModel";
        private const string ViewMatrixVariableName = "uView";
        private const string ProjectionMatrixVariableName = "uProjection";

        private static readonly string VertexShaderSource = @"
        #version 330 core
        layout (location = 0) in vec3 vPos;
		layout (location = 1) in vec4 vCol;

        uniform mat4 uModel;
        uniform mat4 uView;
        uniform mat4 uProjection;

		out vec4 outCol;
        
        void main()
        {
			outCol = vCol;
            gl_Position = uProjection*uView*uModel*vec4(vPos.x, vPos.y, vPos.z, 1.0);
        }
        ";

        private static readonly string FragmentShaderSource = @"
        #version 330 core
        out vec4 FragColor;

		in vec4 outCol;

        void main()
        {
            FragColor = outCol;
        }
        ";

        static void Main(string[] args)
        {
            WindowOptions windowOptions = WindowOptions.Default;
            windowOptions.Title = "2 szeminárium";
            windowOptions.Size = new Vector2D<int>(500, 500);

            // on some systems there is no depth buffer by default, so we need to make sure one is created
            windowOptions.PreferredDepthBufferBits = 24;

            window = Window.Create(windowOptions);

            window.Load += Window_Load;
            window.Update += Window_Update;
            window.Render += Window_Render;
            window.Closing += Window_Closing;

            window.Run();
        }

        private static void Window_Load()
        {
            //Console.WriteLine("Load");

            // set up input handling
            IInputContext inputContext = window.CreateInput();
            foreach (var keyboard in inputContext.Keyboards)
            {
                keyboard.KeyDown += Keyboard_KeyDown;
            }

            Gl = window.CreateOpenGL();
            Gl.ClearColor(System.Drawing.Color.White);

            SetUpObjects();

            LinkProgram();

            Gl.Enable(EnableCap.CullFace);

            Gl.Enable(EnableCap.DepthTest);
            Gl.DepthFunc(DepthFunction.Lequal);
        }

        private static void LinkProgram()
        {
            uint vshader = Gl.CreateShader(ShaderType.VertexShader);
            uint fshader = Gl.CreateShader(ShaderType.FragmentShader);

            Gl.ShaderSource(vshader, VertexShaderSource);
            Gl.CompileShader(vshader);
            Gl.GetShader(vshader, ShaderParameterName.CompileStatus, out int vStatus);
            if (vStatus != (int)GLEnum.True)
                throw new Exception("Vertex shader failed to compile: " + Gl.GetShaderInfoLog(vshader));

            Gl.ShaderSource(fshader, FragmentShaderSource);
            Gl.CompileShader(fshader);

            program = Gl.CreateProgram();
            Gl.AttachShader(program, vshader);
            Gl.AttachShader(program, fshader);
            Gl.LinkProgram(program);
            Gl.GetProgram(program, GLEnum.LinkStatus, out var status);
            if (status == 0)
            {
                Console.WriteLine($"Error linking shader {Gl.GetProgramInfoLog(program)}");
            }
            Gl.DetachShader(program, vshader);
            Gl.DetachShader(program, fshader);
            Gl.DeleteShader(vshader);
            Gl.DeleteShader(fshader);
        }

        private static void Keyboard_KeyPressed(IKeyboard keyboard)
        {
            if (keyboard.IsKeyPressed(Key.Left))
            {
                cameraDescriptor.DecreaseZYAngle();
            }
            if (keyboard.IsKeyPressed(Key.Right))
            {
                cameraDescriptor.IncreaseZYAngle();
            }
            if (keyboard.IsKeyPressed(Key.Down))
            {
                cameraDescriptor.IncreaseDistance();
            }
            if (keyboard.IsKeyPressed(Key.Up))
            {
                cameraDescriptor.DecreaseDistance();
            }
            if (keyboard.IsKeyPressed(Key.U))
            {
                cameraDescriptor.IncreaseZXAngle();
            }
            if (keyboard.IsKeyPressed(Key.D))
            {
                cameraDescriptor.DecreaseZXAngle();
            }            
        }

        private static void Keyboard_KeyDown(IKeyboard keyboard, Key key, int arg3)
        {
            switch (key)
            {
                case Key.Space:
                    cubeArrangementModel.AnimationEnabeld = !cubeArrangementModel.AnimationEnabeld;
                    break;
                //elforgat narancs
                case Key.Keypad1:
                    lepes.Add((1, float.Pi / 2));
                    forgat = true;
                    break;
                case Key.Keypad2:
                    lepes.Add((1, -float.Pi / 2));
                    forgat = true;
                    break;
                //elforgat piros
                case Key.Keypad3:
                    lepes.Add((2, float.Pi / 2));
                    forgat = true;
                    break;
                case Key.Keypad4:
                    lepes.Add((2, -float.Pi / 2));
                    forgat = true;
                    break;
                //elforgat zold
                case Key.Keypad5:
                    lepes.Add((3, float.Pi / 2));
                    forgat = true;
                    break;
                case Key.Keypad6:
                    lepes.Add((3, -float.Pi / 2));
                    forgat = true;
                    break;
                //elforgat kek
                case Key.Keypad7:
                    lepes.Add((4, float.Pi / 2));
                    forgat = true;
                    break;
                case Key.Keypad8:
                    lepes.Add((4, -float.Pi / 2));
                    forgat = true;
                    break;
                //elforgat sarga
                case Key.Keypad9:
                    lepes.Add((5, float.Pi / 2));
                    forgat = true;
                    break;
                case Key.Keypad0:
                    lepes.Add((5, -float.Pi / 2));
                    forgat = true;
                    break;
                //elforgat feher
                case Key.Home:
                    lepes.Add((6, float.Pi / 2));
                    forgat = true;
                    break;
                case Key.End:
                    lepes.Add((6, -float.Pi / 2));
                    forgat = true;
                    break;
                //30 random forgatas generalasa
                case Key.R:
                    for (int i = 0; i < 30; i++)
                    {
                        int randomNumber = random.Next(1, 7);
                        int elojel = random.Next(1, 3);
                        if (elojel == 1) { lepes.Add((randomNumber, -float.Pi / 2)); }
                        else { lepes.Add((randomNumber, float.Pi / 2)); }
                    }
                    break;
            }
        }

        private static void Window_Update(double deltaTime)
        {
            //Console.WriteLine($"Update after {deltaTime} [s].");
            // multithreaded
            // make sure it is threadsafe
            // NO GL calls
            var keyboard = window.CreateInput().Keyboards[0];
            Keyboard_KeyPressed(keyboard);

            cubeArrangementModel.AdvanceTime(deltaTime);
        }

        private static unsafe void Window_Render(double deltaTime)
        {
            //Console.WriteLine($"Render after {deltaTime} [s].");

            // GL here
            Gl.Clear(ClearBufferMask.ColorBufferBit);
            Gl.Clear(ClearBufferMask.DepthBufferBit);

            Gl.UseProgram(program);

            SetViewMatrix();
            SetProjectionMatrix();

            //DrawPulsingCenterCube();
            //DrawRevolvingCube();

            if (forgat)
            {
                var lastRotationAngle = lepes[lepes.Count - 1].Item2; // Az utolsó forgatási szög
                var rotationSpeed = MathF.PI / 2; // Forgatási sebesség (90 fok / másodperc)

                // Animáció időzítése az adott deltaTime alapján
                if (lastRotationAngle > 0)
                {
                    segedSzog += rotationSpeed * (float)deltaTime;
                }
                else
                {
                    segedSzog -= rotationSpeed * (float)deltaTime;
                }
                // Ha elérte vagy túllépte a cél forgatási szöget, állítsa vissza a sebességet és a 'forgat' flaget
                if (Math.Abs(segedSzog) >= Math.Abs(lastRotationAngle))
                {
                    segedSzog = lastRotationAngle; // Pontosan állítsa be az utolsó szöget
                    forgat = false; // Állítsa vissza a flaget
                }
            }
            else { segedSzog = 0.0f; }

            for (int i = 0; i < rcElements.Count; i++)
            {
                DrawRubicCubeElement(rcElements[i]);
            }
        }

        private static unsafe void DrawRubicCubeElement(RubicCubeElement cubeElement)
        {
            var modelMatrixForCenterCube = Matrix4X4.CreateScale((float)cubeArrangementModel.CenterCubeScale);  //emiatt luktet - nem kell
            Matrix4X4<float> diamondScale = Matrix4X4.CreateScale(0.95f); // fix
            Matrix4X4<float> trans = Matrix4X4.CreateTranslation(cubeElement.x, cubeElement.y, cubeElement.z); // pozicio valtozik
            Matrix4X4<float> modelMatrix = diamondScale * trans;

            int lepesCount = lepes.Count;
            float szog;
            for (int i = 0; i < lepesCount; i++)
            {
                (int, float) lep = lepes[i];
                szog = lep.Item2;
                if (i == lepesCount - 1 && forgat)
                {
                    szog = segedSzog;
                }

                if ((lep.Item1 == 1) && Math.Abs(modelMatrix.M41 - 1f) < tolerance)
                {
                    modelMatrix.M41 = 1;
                    modelMatrix *= Matrix4X4.CreateRotationX(szog);
                }

                if ((lep.Item1 == 2) && Math.Abs(modelMatrix.M41 + 1f) < tolerance)
                {
                    modelMatrix.M41 = -1;
                    modelMatrix *= Matrix4X4.CreateRotationX(szog);
                }

                if ((lep.Item1 == 3) && Math.Abs(modelMatrix.M43 - 1f) < tolerance)
                {
                    modelMatrix.M43 = 1;
                    modelMatrix *= Matrix4X4.CreateRotationZ(szog);
                }

                if ((lep.Item1 == 4) && Math.Abs(modelMatrix.M43 + 1f) < tolerance)
                {
                    modelMatrix.M43 = -1;
                    modelMatrix *= Matrix4X4.CreateRotationZ(szog);
                }

                if ((lep.Item1 == 5) && Math.Abs(modelMatrix.M42 - 1f) < tolerance)
                {
                    modelMatrix.M42 = 1;
                    modelMatrix *= Matrix4X4.CreateRotationY(szog);
                }

                if ((lep.Item1 == 6) && Math.Abs(modelMatrix.M42 + 1f) < tolerance)
                {
                    modelMatrix.M42 = -1;
                    modelMatrix *= Matrix4X4.CreateRotationY(szog);
                }
            }

            modelMatrix *= modelMatrixForCenterCube;

            SetModelMatrix(modelMatrix);
            Gl.BindVertexArray(cubeElement.glCube.Vao); // glCuve is mas
            Gl.DrawElements(GLEnum.Triangles, cubeElement.glCube.IndexArrayLength, GLEnum.UnsignedInt, null);
            Gl.BindVertexArray(0);
        }
      
        private static unsafe void DrawRevolvingCube()
        {
            Matrix4X4<float> diamondScale = Matrix4X4.CreateScale(0.25f);           //nagyitas
            Matrix4X4<float> rotx = Matrix4X4.CreateRotationX((float)Math.PI / 4f); //forgatasok
            Matrix4X4<float> rotz = Matrix4X4.CreateRotationZ((float)Math.PI / 4f);
            Matrix4X4<float> rotLocY = Matrix4X4.CreateRotationY((float)cubeArrangementModel.DiamondCubeAngleOwnRevolution);    //emiatt pordul
            Matrix4X4<float> trans = Matrix4X4.CreateTranslation(1f, 1f, 0f);
            Matrix4X4<float> rotGlobY = Matrix4X4.CreateRotationY((float)cubeArrangementModel.DiamondCubeAngleRevolutionOnGlobalY);
            Matrix4X4<float> modelMatrix = diamondScale * rotx * rotz * rotLocY * trans * rotGlobY;

            SetModelMatrix(modelMatrix);
            Gl.BindVertexArray(glCubeRotating.Vao);
            Gl.DrawElements(GLEnum.Triangles, glCubeRotating.IndexArrayLength, GLEnum.UnsignedInt, null);
            Gl.BindVertexArray(0);
        }

        private static unsafe void DrawPulsingCenterCube()
        {
            Matrix4X4<float> diamondScale = Matrix4X4.CreateScale(0.95f);       //ezt en irtam, hogy legyen kisebb
            var modelMatrixForCenterCube = Matrix4X4.CreateScale((float)cubeArrangementModel.CenterCubeScale);  //emiatt luktet
            SetModelMatrix(diamondScale * modelMatrixForCenterCube);
            Gl.BindVertexArray(glCubeCentered.Vao);
            Gl.DrawElements(GLEnum.Triangles, glCubeCentered.IndexArrayLength, GLEnum.UnsignedInt, null);
            Gl.BindVertexArray(0);
        }

        private static unsafe void SetModelMatrix(Matrix4X4<float> modelMatrix)
        {
            int location = Gl.GetUniformLocation(program, ModelMatrixVariableName);
            if (location == -1)
            {
                throw new Exception($"{ModelMatrixVariableName} uniform not found on shader.");
            }

            Gl.UniformMatrix4(location, 1, false, (float*)&modelMatrix);
            CheckError();
        }

        private static unsafe void SetUpObjects()
        {
            /*
            float[] face1Color = [0.5f, 0.0f, 0.0f, 1.0f];
            float[] face2Color = [0.0f, 0.5f, 0.0f, 1.0f];
            float[] face3Color = [0.0f, 0.0f, 0.5f, 1.0f];
            float[] face4Color = [0.5f, 0.0f, 0.5f, 1.0f];
            float[] face5Color = [0.0f, 0.5f, 0.5f, 1.0f];
            float[] face6Color = [0.5f, 0.5f, 0.0f, 1.0f];
            glCubeRotating = GlCube.CreateCubeWithFaceColors(Gl, face1Color, face2Color, face3Color, face4Color, face5Color, face6Color);
            */

            //0,0,0 mindennek a kozepe
            float[] xIndex = { 
                -1f,     1f, -1f,  0f, 1f, -1f, 0f, 1f, //kozepso lap
                -1f, 0f, 1f, -1f,  0f, 1f, -1f, 0f, 1f, //also lap
                -1f, 0f, 1f, -1f,  0f, 1f, -1f, 0f, 1f, //felso lap
            };
            float[] yIndex = { 
                 0f,       0f,  0f,  0f,  0f,  0f,  0f,  0f, //kozepso lap
                -1f, -1f, -1f, -1f, -1f, -1f, -1f, -1f, -1f, //also lap
                 1f,  1f,  1f,  1f,  1f,  1f,  1f,  1f,  1f, //felso lap
            };
            float[] zIndex = {
                0f,     0f, -1f, -1f, -1f, 1f, 1f, 1f,  //kozepso lap
                0f, 0f, 0f, -1f, -1f, -1f, 1f, 1f, 1f,  //also lap
                0f, 0f, 0f, -1f, -1f, -1f, 1f, 1f, 1f,  //felso lap
            };

            float[] feher = [1.0f, 1.0f, 1.0f, 1.0f];  //feher
            float[] zold = [0.0f, 1.0f, 0.0f, 1.0f];  //zold
            float[] narancs = [1.0f, 0.5f, 0.0f, 1.0f];  //narancs
            float[] sarga = [1.0f, 1.0f, 0.0f, 1.0f];  //sarga
            float[] kek = [0.0f, 0.0f, 1.0f, 0.0f];  //kek
            float[] piros = [1.0f, 0.0f, 0.0f, 1.0f]; //piros
            float[] fekete = [0.0f, 0.0f, 0.0f, 1.0f]; //fekete

            //glCubeCentered = GlCube.CreateCubeWithFaceColors(Gl, teto, alapSzembeni, balOldal, also, hatololdal, jobbOldal);
            //glCubeCentered = GlCube.CreateCubeWithFaceColors(Gl, face1Color, face2Color, face3Color, face4Color, fekete, face6Color);
            List<GlCube> szineKockak = new List<GlCube>();
            //kozepso oldal
            szineKockak.Add(GlCube.CreateCubeWithFaceColors(Gl, fekete, fekete, piros, fekete, fekete, fekete));
            szineKockak.Add(GlCube.CreateCubeWithFaceColors(Gl, fekete, fekete, fekete, fekete, fekete, narancs));
            szineKockak.Add(GlCube.CreateCubeWithFaceColors(Gl, fekete, fekete, piros, fekete, kek, fekete));
            szineKockak.Add(GlCube.CreateCubeWithFaceColors(Gl, fekete, fekete, fekete, fekete, kek, fekete));
            szineKockak.Add(GlCube.CreateCubeWithFaceColors(Gl, fekete, fekete, fekete, fekete, kek, narancs));
            szineKockak.Add(GlCube.CreateCubeWithFaceColors(Gl, fekete, zold, piros, fekete, fekete, fekete));
            szineKockak.Add(GlCube.CreateCubeWithFaceColors(Gl, fekete, zold, fekete, fekete, fekete, fekete));
            szineKockak.Add(GlCube.CreateCubeWithFaceColors(Gl, fekete, zold, fekete, fekete, fekete, narancs));
            //also Oldal
            szineKockak.Add(GlCube.CreateCubeWithFaceColors(Gl, fekete, fekete, piros, feher, fekete, fekete));
            szineKockak.Add(GlCube.CreateCubeWithFaceColors(Gl, fekete, fekete, fekete, feher, fekete, fekete));
            szineKockak.Add(GlCube.CreateCubeWithFaceColors(Gl, fekete, fekete, fekete, feher, fekete, narancs));
            szineKockak.Add(GlCube.CreateCubeWithFaceColors(Gl, fekete, fekete, piros, feher, kek, fekete));
            szineKockak.Add(GlCube.CreateCubeWithFaceColors(Gl, fekete, fekete, fekete, feher, kek, fekete));
            szineKockak.Add(GlCube.CreateCubeWithFaceColors(Gl, fekete, fekete, fekete, feher, kek, narancs));
            szineKockak.Add(GlCube.CreateCubeWithFaceColors(Gl, fekete, zold, piros, feher, fekete, fekete));
            szineKockak.Add(GlCube.CreateCubeWithFaceColors(Gl, fekete, zold, fekete, feher, fekete, fekete));
            szineKockak.Add(GlCube.CreateCubeWithFaceColors(Gl, fekete, zold, fekete, feher, fekete, narancs));
            //felso oldal
            szineKockak.Add(GlCube.CreateCubeWithFaceColors(Gl, sarga, fekete, piros, fekete, fekete, fekete));
            szineKockak.Add(GlCube.CreateCubeWithFaceColors(Gl, sarga, fekete, fekete, fekete, fekete, fekete));
            szineKockak.Add(GlCube.CreateCubeWithFaceColors(Gl, sarga, fekete, fekete, fekete, fekete, narancs));
            szineKockak.Add(GlCube.CreateCubeWithFaceColors(Gl, sarga, fekete, piros, fekete, kek, fekete));
            szineKockak.Add(GlCube.CreateCubeWithFaceColors(Gl, sarga, fekete, fekete, fekete, kek, fekete));
            szineKockak.Add(GlCube.CreateCubeWithFaceColors(Gl, sarga, fekete, fekete, fekete, kek, narancs));
            szineKockak.Add(GlCube.CreateCubeWithFaceColors(Gl, sarga, zold, piros, fekete, fekete, fekete));
            szineKockak.Add(GlCube.CreateCubeWithFaceColors(Gl, sarga, zold, fekete, fekete, fekete, fekete));
            szineKockak.Add(GlCube.CreateCubeWithFaceColors(Gl, sarga, zold, fekete, fekete, fekete, narancs));


            rcElements = new List<RubicCubeElement>();
            for (int i = 0; i < xIndex.Length; i++)
            {
                rcElements.Add(new RubicCubeElement(szineKockak[i], xIndex[i], yIndex[i], zIndex[i]));
            }
        }

        private static void Window_Closing()
        {
            //glCubeCentered.ReleaseGlCube();
            //glCubeRotating.ReleaseGlCube();

            for (int i = 0; i < rcElements.Count; i++)
            {
                rcElements[i].glCube.ReleaseGlCube();
            }
        }

        private static unsafe void SetProjectionMatrix()
        {
            var projectionMatrix = Matrix4X4.CreatePerspectiveFieldOfView<float>((float)Math.PI / 4f, 1024f / 768f, 0.1f, 100);
            int location = Gl.GetUniformLocation(program, ProjectionMatrixVariableName);

            if (location == -1)
            {
                throw new Exception($"{ViewMatrixVariableName} uniform not found on shader.");
            }

            Gl.UniformMatrix4(location, 1, false, (float*)&projectionMatrix);
            CheckError();
        }

        private static unsafe void SetViewMatrix()
        {
            var viewMatrix = Matrix4X4.CreateLookAt(cameraDescriptor.Position, cameraDescriptor.Target, cameraDescriptor.UpVector);
            int location = Gl.GetUniformLocation(program, ViewMatrixVariableName);

            if (location == -1)
            {
                throw new Exception($"{ViewMatrixVariableName} uniform not found on shader.");
            }

            Gl.UniformMatrix4(location, 1, false, (float*)&viewMatrix);
            CheckError();
        }

        public static void CheckError()
        {
            var error = (ErrorCode)Gl.GetError();
            if (error != ErrorCode.NoError)
                throw new Exception("GL.GetError() returned " + error.ToString());
        }
    }
}